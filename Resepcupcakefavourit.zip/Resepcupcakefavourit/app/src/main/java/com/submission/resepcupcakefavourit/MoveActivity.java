package com.submission.resepcupcakefavourit;

public class MoveActivity {
}
