package com.submission.resepcupcakefavourit;

import java.util.ArrayList;

class cupcakesData {
    private static String[] cupcakesNames = {
            "Vanilla cupcakes",
            "Rose cupcake",
            "Cupcake cokelat kukus",
            "Triple choco cupcake",
            "Brownies cup",
            "Super moist chocolate cupcake",
            "Matcha muffin",
            "Muffin almond choco chips",
            "Eggless cupcake",
            "Condensed milk cupcake"
    };

    private static String[] cupcakeDetails = {
            "1. Vanilla cupcakes.\n" +
                    "Bahan-bahan:\n" +
                    "- 200 gr tepung terigu serba guna\n" +
                    "- 100 gr unsalted butter (mentega tawar)\n" +
                    "- 2 butir telur\n" +
                    "- 180 gr gula kastor (bisa pakai gula pasir biasa)\n" +
                    "- 1 sdt baking powder\n" +
                    "- 125 ml susu cair\n" +
                    "- 1 sdt vanilla extract\n" +
                    "Butter cream:\n" +
                    "- 250 gr butter\n" +
                    "- 150 gr icing sugar\n" +
                    "- 3 sdm susu cair\n" +
                    "- 1 sdt vanilla extract\n" +
                    "- Secukupnya pewarna makanan" +
                    "Cara membuat:\n" +
                    "- Mix unsalted butter, gula, vanilla dengan mixer hingga mengembang dan pucat\n" +
                    "- Tambahkan telur satu persatu, di-mix sampai tercampur rata dan di-mix sampai kental\n" +
                    "- Tambahkan tepung terigu yang telah dicampur baking powder, bergantian dengan susu cair. Sambil dicampur dengan mixer kecepatan rendah. Lakukan sampai habis\n" +
                    "- Tuang adonan kedalam cetakan cupcake yang telah dilapisi cup cases, panggang di suhu 180 selama 25-30 menit, sesuaikan dengan oven masing-masing\n" +
                    "- Angkat, biarkan dingin\n" +
                    "\n" +
                    "Butter cream:\n" +
                    "- Mix butter sampai rata dan mengembang, tambahkan icing sugar dan mix dengan mixer kecepatan tinggi sampai berwarna putih, tambahkan vanilla dan susu cair. Di-mix kembali sampai kental, mengembang dan berwarna putih\n" +
                    "- Bagi butter cream menjadi 3 wadah, satu beri pewarna hitam, sedikit saja kurang lebih 3 sdm. Satunya warna merah dan satunya biarkan putih, masukkan ke dalam 3 buah piping bag beri spuit bintang yang kecil, lalu semprotkan ke atas cupcake.",
            "2. Rose cupcake.\n" +
                    "Bahan-bahan:\n" +
                    "- 3 butir telur\n" +
                    "- 100 gr gula kastor\n" +
                    "- 130 gr tepung terigu serba guna\n" +
                    "- 1/8 sdt garam\n" +
                    "- 50 ml susu cair\n" +
                    "- 50 ml minyak sayur\n" +
                    "- Secukupnya selai coklat untuk filling\n" +
                    "- Secukupnya buttercream untuk topping\n" +
                    "\n" +
                    "Cara membuat:\n" +
                    "- Kocok telur dan gula sampai mengembang dan kental. Masukkan tepung terigu, coklat bubuk dan garam yang telah diayak bergantian dengan susu cair dan minyak sayur. Mix dengan mixer kecepatan rendah sampai rata\n" +
                    "- Masukkan adonan ke dalam cupcake case. Panggang 25 menit dengan suhu 180°C atau sesuaikan dengan oven masing-masing\n" +
                    "- Lubangi cupcake dengan menggunakan spuit lalu semprotkan selai cokelat ke dalamnya dan tutup kembali\n" +
                    "- Oles buttercream di permukaan cupcake lalu hias dengan buttercream sesuai selera.\n",
            "3. Cupcake cokelat kukus.\n" +
                    "Bahan-bahan:\n" +
                    "- 4 butir telur utuh\n" +
                    "- 200 gr gula pasir butiran halus\n" +
                    "- 1 sdm emulsifier, TBM, Ovalet, SP\n" +
                    "- 110 gram tepung Segitiga Biru\n" +
                    "- 2 sdm cokelat bubuk\n" +
                    "- 150 ml minyak goreng\n" +
                    "- 1-2 sdm pasta cokelat pakai yang good quality\n" +
                    "- 75 gr cokelat batang, serut, lelehkan, diamkan suhu ruang\n" +
                    "\n" +
                    "Cara membuat:\n" +
                    "- Campurkan telur dan gula, kocok sebentar, masukkan emulsifier, kocok hingga kental dan mengembang\n" +
                    "- Masukkan tepung terigu, cokelat bubuk dengan cara diayak, aduk balik menggunakan spatula\n" +
                    "- Tuang minyak goreng, pasta, coklat leleh ke dalam adonan, campur hingga rata\n" +
                    "- Tuang adonan ke dalam cup/alumunium foil.\n" +
                    "- Kukus selama 20-25 menit\n" +
                    "- Sajikan.",
            "4. Triple choco cupcake.\n" +
                    "Bahan A:\n" +
                    "- 180 gr tepung terigu prot sedang\n" +
                    "- 20 gr cokelat bubuk\n" +
                    "- 1/2 sdt BPDA (Baking Powder Double Acting)\n" +
                    "\n" +
                    "Bahan B:\n" +
                    "- 125 gr butter\n" +
                    "- 170 gr gula halus\n" +
                    "- 2 butir telur\n" +
                    "- 100 ml susu cair\n" +
                    "\n" +
                    "Cara membuat:\n" +
                    "- Campur bahan A jadi satu, lalu ayak. Sisihkan\n" +
                    "- Kocok bahan B hingga mengembang halus. Lalu masukkan telur satu persatu sambil di-mix. Matikan mixer\n" +
                    "- Tuang bahan A dan susu cair secara bergantian. Dimulai dari tepung dan diakhiri dengan tepung.\n" +
                    "- Tuang ke cup kertas sebanyak 3/4 cup. Dioven suhu 175 derajat Celcius selama 25 menit atau sesuaikan oven masing-masing. Angkat lalu dinginkan\n" +
                    "- Buat lubang di tengah cupcake, beri filling choco chrunch, semprot ganache di atasnya\n" +
                    "\n" +
                    "Filling: Choco chrunch\n" +
                    "\n" +
                    "Ganache coklat:\n" +
                    "- 160 gr dcc (dark cooking chocolate), lelehkan\n" +
                    "- 80 gr whipcream bubuk\n" +
                    "- 160 ml air es\n" +
                    "\n" +
                    "Cara membuatnya :\n" +
                    "- Mix whipcream bubuk dan air es hingga mengembang, tuang dcc leleh, mix hingga tercampur rata. Siap disajikan.",
            "5. Brownies cup.\n" +
                    "Bahan A:\n" +
                    "- 175 gr DCC (dark cooking chocolate)/cokelat batang\n" +
                    "- 100 gr mentega\n" +
                    "- 30 ml minyak sayur\n" +
                    "\n" +
                    "Bahan B:\n" +
                    "- 2 butir telur utuh\n" +
                    "- 125 gr gula halus\n" +
                    "- 1/2 sdt garam\n" +
                    "\n" +
                    "Bahan C (ayak):\n" +
                    "- 150 gr tepung terigu serbaguna\n" +
                    "- 1 sdm susu bubuk\n" +
                    "- 10 gr cokelat bubuk\n" +
                    "\n" +
                    "Cara membuat:\n" +
                    "- Tim/lelehkan bahan A lalu sisihkan\n" +
                    "- Kocok bahan B dengan whisker hingga gula larut\n" +
                    "- Tuang bahan A ke dalam bahan B aduk rata, masukkan bahan C aduk hingga tercampur rata\n" +
                    "- Tuang dalam papercup\n" +
                    "- Beri bahan topping sesuai selera\n" +
                    "- Panggang dalam oven suhu 170 derajat Celcius selama kurang lebih 25-30menit\n" +
                    "- Siap dinikmati.\n",
            "6. Super moist chocolate cupcake.\n" +
                    "Bahan-bahan:\n" +
                    "- 95 gr tepung serba guna\n" +
                    "- 45 gr cocoa powder\n" +
                    "- 3/4 sdt baking powder\n" +
                    "- 1/2 sdt baking soda\n" +
                    "- 1/4 sdt garam\n" +
                    "- 2 butir telur ukuran besar, diamkan di suhu ruang\n" +
                    "- 50 g gula pasir\n" +
                    "- 50 g brown sugar\n" +
                    "- 180 ml canola oil atau minyak sayur\n" +
                    "- 1 sdt vanilla extract\n" +
                    "- 120 ml susu\n" +
                    "- 1 sdm air lemon (buttermilk), campur lalu diamkan 10 menit hingga mengental\n" +
                    "\n" +
                    "Cara membuat:\n" +
                    "- Ayak tepung, cocoa powder, baking powder, baking soda dan garam (bahan kering). Sisihkan\n" +
                    "- Di mangkuk lain, campur telur, canola oil, gula pasir, brown sugar menggunakan wisk tangan hingga rata dan gula larut (bahan basah)\n" +
                    "- Tuang setengah bagian basah ke bahan kering, tuang juga sebagian buttermilk, lalu aduk pelan hingga menyatu. Lakukan lagi untuk setengah bagian lainnya. Aduk pelan, aduk seperlunya saja, jangan terlalu banyak mengaduk agar cupcake tidak bantat\n" +
                    "- Tuang adonan ke dalam cetakan cupcakes hanya sampai setengah bagian cetakan saja agar tidak pecah, ketika matang bagian atas cupcake tidak kering dan ukurannya pas ketika akan diberi buttercream\n" +
                    "- Panggang di oven 175 derajat Celcius, 12-15 menit atau sampai matang (suhu dan lama memanggang sesuaikan dengan oven masing-masing), lakukan tes tusuk untuk melihat kematangan cake\n" +
                    "- Beri butter cream favorite.\n",
            "7. Matcha muffin.\n" +
                    "Bahan-bahan:\n" +
                    "- 90 gr gula\n" +
                    "- 1 butir telur\n" +
                    "- 65 gr butter, lelehkan\n" +
                    "- 100 gr terigu\n" +
                    "- 20 gr maizena\n" +
                    "- 10 gr matcha powder\n" +
                    "- 3 gr baking powder\n" +
                    "-90 ml susu cair\n" +
                    "\n" +
                    "Cara membuat:\n" +
                    "- Campur gula, telur, butter, aduk dengan whisk hingga gula larut.\n" +
                    "- Ayak terigu, maizena, matcha and baking powder. Masukkan bertahap, bergantian dengan susu cair. Aduk asal rata\n" +
                    "- Tuang ke muffin pan/paper cup. Beri topping sesuai selera.\n" +
                    "- Panggang api atas bawah suhu 180 derajat Celcius, selama 15 menit atau sesuaikan dengan oven masing-masing.",
            "8. Muffin almond choco chips.\n" +
                    "Bahan-bahan:\n" +
                    "- 100 gr margarine, 25 gr butter\n" +
                    "- 50 ml susu cair\n" +
                    "- 2 butir telur\n" +
                    "- 125 gr gula pasir\n" +
                    "- 200 gr tepung terigu\n" +
                    "- 20 gr cokelat bubuk\n" +
                    "- 1 sdt soda kue\n" +
                    "- 1 sdt baking powder\n" +
                    "- 150 gr choco chips\n" +
                    "\n" +
                    "Cara membuat:\n" +
                    "- Panaskan di oven dengan temperatur 200 derajat Celcius, siapkan cetakan muffin beri kertas cup\n" +
                    "- Ayak tepung terigu, soda kue, baking powder, dan cokelat bubuk jadi satu, sisihkan\n" +
                    "- Cairkan margarin, butter bersama cucu cair asal hangat saja, tidak sampai mendidih, angkat\n" +
                    "- Kocok telur dan gula dengan mixer kecepatan sedang. Asal gula larut saja\n" +
                    "- Masukkan campuran tepung, aduk rata\n" +
                    "- Masukkan larutan margarin, aduk rata perlahan. Tambahkan choco chips, aduk rata\n" +
                    "- Tuang adonan ke dalam cetakan muffin sampai 3/4 penuh\n" +
                    "- Taburi almond\n" +
                    "- Panggang 200 derajat Celcius selama 25 menit hingga matang\n" +
                    "- Angkat dan sajikan.",
            "9. Eggless cupcake.\n" +
                    "Bahan A:\n" +
                    "- 80 gr terigu\n" +
                    "- 25 gr cocoa powder\n" +
                    "- 80 gr gula pasir\n" +
                    "- 1 sdm susu bubuk\n" +
                    "- 1/2 sdt baking powder\n" +
                    "- 1/4 sdt baking soda\n" +
                    "- secubit garam\n" +
                    "\n" +
                    "Bahan B:\n" +
                    "- 150 gr susu cair\n" +
                    "- 50 ml minyak sayur\n" +
                    "- 1/2 sdt pasta susu\n" +
                    "\n" +
                    "cara membuat:\n" +
                    "- Siapkan wadah, campur rata bahan A\n" +
                    "- Lalu campur bahan B, aduk dengan wisk sampai rata\n" +
                    "- Isi ke dalam cupcase, masukkan oven 35 menit dengan suhu 175 derajat Celcius/sampai matang",
            "10. Condensed milk cupcake.\n" +
                    "Bahan A:\n" +
                    "- 3 butir kuning telur\n" +
                    "- 1 butir telur utuh\n" +
                    "- 45 gr minyak makan\n" +
                    "- 50 gr tepung protein rendah, ayak\n" +
                    "- 30 gr susu kental manis (SKM)\n" +
                    "- 1-2 tetes air perasan lemon\n" +
                    "\n" +
                    "Bahan B:\n" +
                    "- 3 butir putih telur\n" +
                    "- 35 gr gula pasir butiran halus\n" +
                    "\n" +
                    "Cara membuat:\n" +
                    "- Panaskan minyak makan hingga 85 derajat Celcius\n" +
                    "Tuang ke dalam mangkok yang berisi epung. Aduk rata. Masukkan kuning telur dan telur utuh. Aduk rata. Masukkan SKM dan air lemon. Aduk rata kembali\n" +
                    "- Kocok putih telur dan gula pasir (bagi 3 tahap) hingga kaku. Campur ke adonan kuning telur (bagi 3 tahap). Aduk lipat dengan spatula\n" +
                    "- Tuang ke dalam cetakan yang telah diberi kertas cupcake\n" +
                    "- Panggang di oven dengan suhu 120 derajat Celcius selama 45 menit\n" +
                    "- Lanjut dengan suhu 150 derajat Celcius selama 15 menit/hingga kecoklatan\n" +
                    "- Matikan api, biarkan cupcake dalam oven selama 5 menit."
    };

    private static int[] cupcakesImages = {
            R.drawable.vanilla_cupcakes,
            R.drawable.rose_cupcake,
            R.drawable.cupcake_cokelat_kukus,
            R.drawable.triple_choco_cupcake,
            R.drawable.brownies_cup,
            R.drawable.super_moist_chocolate_cupcake,
            R.drawable.matcha_muffin,
            R.drawable.muffin_almond_choco_chips,
            R.drawable.eggless_cupcake,
            R.drawable.condensed_milk_cupcake
    };

    static ArrayList<Cupcake> getListData() {
        ArrayList<Cupcake> list = new ArrayList<>();
        for (int position = 0; position < cupcakesNames.length; position++) {
            Cupcake cupcake = new Cupcake();
            cupcake.setName(cupcakesNames[position]);
            cupcake.setDetail(cupcakeDetails[position]);
            cupcake.setPhoto(cupcakesImages[position]);
            list.add(cupcake);
        }
        return list;
    }
}