package com.submission.resepcupcakefavourit;

import android.app.Activity;

public class About extends Activity {
}
