package com.submission.resepcupcakefavourit;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MoveWithDataActivity extends AppCompatActivity {
    public static final String EXTRA_NAMES = "extra_names";
    public static final String EXTRA_DETAILS = "extra_details";
    public static final Integer EXTRA_IMAGES = "extra_images";
    private String details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move_with_data);

        TextView tvDataReceived = findViewById(R.id.tv_data_received);
        String names = getIntent().getStringExtra(EXTRA_NAMES);
        String names = getIntent().getStringExtra(EXTRA_DETAILS);
        int images = getIntent().getIntExtra(EXTRA_IMAGES);
        String text = "Names : " + names + ";
        tvDataReceived.setText(text);
        String text = "Details : " + details + " ;
        tvDataReceived.setText(text);
        Integer ="Images" : " + images + " ;
        tvDataReceived.setInputExtras(images;

    }
}
